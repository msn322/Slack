<?php

header("Content-Type: text/plain");
echo "Hello, Slack!\n";
